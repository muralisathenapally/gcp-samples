import base64

def process_pubsub_event(event, context):
  message = base64.b64decode(event['data']).decode('utf-8')

  secret_name = message.get('name')
  roation_time = message['rotation']['nextRotationTime']

  print("Rotate Secret:" + secret_name + " Next Roation Time:" + roation_time)