import datetime
from datetime import date
import uuid
import json
import base64
import string
import re
import requests
import os
from string import Template

date = datetime.datetime.now()
print("Time now is ", date)

from pydantic import BaseModel
from google.cloud import bigquery
from google.cloud import resourcemanager_v3
import json
from google.cloud import storage
from ast import literal_eval


from flask import Flask, request

ack_url = os.environ.get('ACK_SERVICE_URL')
project = os.environ.get('PROJECT')
dataset = os.environ.get('DATASET')
table = os.environ.get('TABLE')

today_folder = date.strftime('%Y-%m-%d')
print("Folder:",today_folder)

app = Flask(__name__)


# [START cloudrun_pubsub_handler]
# [START run_pubsub_handler]
@app.route("/", methods=["POST"])
def index():
    """Receive and parse Pub/Sub messages."""
    envelope = request.get_json()
    if not envelope:
        msg = "no Pub/Sub message received"
        print(f"error: {msg}")
        return f"Bad Request: {msg}", 400

    if not isinstance(envelope, dict) or "message" not in envelope:
        msg = "invalid Pub/Sub message format"
        print(f"error: {msg}")
        return f"Bad Request: {msg}", 400

    pubsub_message = envelope["message"]
    print("Type of message in pubsub in raw format is of the type:", type(pubsub_message))
    print("Message looks like this:\n", pubsub_message)

    original_asset_data = "Initialized data for original_asset_data"
    if isinstance(pubsub_message, dict) and "data" in pubsub_message:
        original_asset_data = base64.b64decode(pubsub_message["data"]).decode("utf-8").strip()
        original_asset_data_encoded = pubsub_message["data"]

    print(f"Processing started for UGCS Governance - Resource/Services updates!")

# BEGIN data enrichment and transformation ##########################################################

    guidstr = str(uuid.uuid4())
    # grab created timestamp
    asset_json = json.loads(original_asset_data)
    created_ts = asset_json["window"]["startTime"]
    #### *** The below line needs to be updated after 'gcloud run deploy' of ack Cloud Run service
    ackurl = ack_url + "/ack?uuid={id_to_ack}".format(id_to_ack=guidstr)

    asset_type = asset_json["asset"]["assetType"]
    asset_name = asset_json["asset"]["name"]
    event_type = "CAI-triggered event"
    if 'deleted' not in asset_json:
        event_type = "CREATE or UPDATE event"
    else:
        event_type = "DELETE event"

    print("UUID:", guidstr)
    print("type-of-change:", event_type)
    print("created timestamp:", created_ts)
## END data enrichment and transformation ###########################################################

################### BEGIN data comms with Teams #####################################################
    print("Begin comms with Teams")
    whurl = 'https://usptogov.webhook.office.com/webhookb2/ec0127f5-b3cd-48c1-be66-440fde342a0d@ff4abfe9-83b5-4026-8b8f-fa69a1cad0b8/IncomingWebhook/1502986abe8a44e48175a0931d704c01/92dfa51d-7b8b-4d78-a3e6-732d8dcaf9bd'

    data_template = Template('{"text": "UGCS RESOURCE UPDATE ALERT - A $eventType happened on $assetType identified by $assetName. \n\n Acknowledge by clicking this URL: $acknowledgeURL"}')
    data = data_template.substitute(eventType=event_type, assetType=asset_type, assetName=asset_name, acknowledgeURL=ackurl)

    response = requests.post(whurl, data=data)
    if(response.status_code == 200):
        print('Successfully sent data over to Teams')
    else:
        print('Error sending data to Teams')
        print(response.status_code)
#################### END data comms with Teams ######################################################

################### BEGIN data persistence ##########################################################
        # Direct insert query
    insert_client = bigquery.Client()
    #insert_stmt = "INSERT `ugcslab-ssb-dev1.sri_dev_assets.asset-updates-sri-cloudrun` (data, uuid, creationtimestamp, notifiedtimestamp, notificationtype) VALUES( {original_asset_data}, {guidstr}, {created_ts}, CURRENT_TIMESTAMP(), 'RESOURCES & SERVICES');"
    insert_stmt = f"INSERT `{project}.{dataset}.{table}` (data, uuid, creationtimestamp, notifiedtimestamp, notificationtype) VALUES( '{original_asset_data_encoded}', '{guidstr}', '{created_ts}', CURRENT_TIMESTAMP(), 'RESOURCES & SERVICES');"
    print("INSERTING notification status in Big query:", insert_stmt)

    # Working - results = client.query(query)
    insert_job = insert_client.query(query=insert_stmt)
    insert_results = insert_job.result()
    print("Result of update query:", insert_results)
    print("Successfully persisted message with uuid:", guidstr)

#################### END data persistence ###########################################################


    print(f"Processed UGCS Governance - Resource/Services updates for:\n{original_asset_data}!")

    return ("", 204)


# [END run_pubsub_handler]
# [END cloudrun_pubsub_handler]
