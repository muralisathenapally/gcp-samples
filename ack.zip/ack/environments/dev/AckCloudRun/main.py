#!/usr/bin/python3
import datetime
from datetime import date
import uuid
import json
import base64
import string
import re
import requests
import os

date = datetime.datetime.now()
print("Time now is ", date)

from fastapi import FastAPI
from pydantic import BaseModel
from google.cloud import bigquery
from google.cloud import resourcemanager_v3
import json
from google.cloud import storage
from ast import literal_eval

app = FastAPI()


today_folder = date.strftime('%Y-%m-%d')
print("Folder:",today_folder)

project = os.environ.get('PROJECT')
dataset = os.environ.get('DATASET')
table = os.environ.get('TABLE')

@app.get("/")
async def root():
    print("You cannot invoke this service without right parameters - ", project, '.', dataset, '.', table)



@app.get("/ack")
async def ack(uuid: str):

    # Direct query
    client = bigquery.Client()
    update = "UPDATE `{project}.{dataset}.{table}` SET acktimestamp = CURRENT_TIMESTAMP() WHERE  uuid='{}';".format(uuid)
    print("UPDATE query:", update)

    # Working - results = client.query(query)
    update_job = client.query(update)
    update_results = update_job.result()
    print("Result of update query:", update_results)
    return {"Successfully updated your response for uuid": uuid}

