# Project Notifications & Acknowledgement System using Teams

This project provides the operational and administrative workflow to trigger realtime notifications about Project resources and services used by project owners. The system integrated with Microsoft Teams channel to send details to project resources/services and seeks acknowledgement from project owner to own up the usage and APIs.

All acknowledgement statuses are captured and persisted in BigQuery.