import json
import logging
import os
import smtplib
from datetime import datetime
from email.message import EmailMessage
from zoneinfo import ZoneInfo

import functions_framework
from google.cloud import bigquery, secretmanager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BILLING_TABLE = os.environ["BILLING_TABLE"]
TIMEZONE = os.getenv("TIMEZONE", "Asia/Kolkata")
PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("PROJECT_ID")

# Only 1 secret ID to manage!
SMTP_SECRET_ID = os.environ.get("SMTP_SECRET_ID", "smtp-credentials")
SMTP_PORT = int(os.environ.get("SMTP_PORT", 587))
SMTP_SENDER = os.environ.get("SMTP_SENDER")


def get_smtp_config() -> dict:
    """Fetch and parse SMTP credentials from a single Secret Manager JSON secret."""
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{PROJECT_ID}/secrets/{SMTP_SECRET_ID}/versions/latest"
    response = client.access_secret_version(request={"name": name})
    secret_payload = response.payload.data.decode("UTF-8")
    return json.loads(secret_payload)


def fetch_billing_data():
    client = bigquery.Client()

    query = f"""
        SELECT
            service.description AS service_name,
            currency,
            SUM(CAST(cost AS NUMERIC))
            + SUM(
                IFNULL(
                    (
                        SELECT SUM(CAST(c.amount AS NUMERIC))
                        FROM UNNEST(credits) AS c
                    ),
                    0
                )
            ) AS net_cost
        FROM `{BILLING_TABLE}`
        WHERE DATE(usage_start_time, @timezone)
              >= DATE_TRUNC(CURRENT_DATE(@timezone), MONTH)
          AND DATE(usage_start_time, @timezone)
              <= CURRENT_DATE(@timezone)
        GROUP BY service_name, currency
        ORDER BY net_cost DESC
    """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("timezone", "STRING", TIMEZONE)
        ]
    )

    return list(client.query(query, job_config=job_config).result())


def generate_report(rows):
    now = datetime.now(ZoneInfo(TIMEZONE))
    start_date = now.date().replace(day=1)
    end_date = now.date()

    totals = {}
    lines = [
        "=" * 90,
        "GCP MONTH-TO-DATE BILLING REPORT",
        f"Period: {start_date} to {end_date}",
        f"Timezone: {TIMEZONE}",
        "=" * 90,
        f"{'SERVICE':<45} {'CURRENCY':<10} {'NET COST':>20}",
        "-" * 90,
    ]

    for row in rows:
        service = row.service_name or "Unknown service"
        currency = row.currency
        cost = row.net_cost

        lines.append(f"{service:<45} {currency:<10} {cost:>20,.2f}")
        totals[currency] = totals.get(currency, 0) + cost

    if not rows:
        lines.append("No billing records found for this period.")

    lines.append("-" * 90)
    for currency, total in sorted(totals.items()):
        lines.append(f"{'TOTAL':<45} {currency:<10} {total:>20,.2f}")
    lines.append("=" * 90)

    report_text = "\n".join(lines)
    logger.info("\n%s", report_text)
    return report_text


def send_email_report(report_body):
    # Fetch all credentials in a single call
    smtp_config = get_smtp_config()
    
    smtp_host = smtp_config["host"]
    smtp_user = smtp_config["user"]
    smtp_password = smtp_config["password"]
    
    # Handle multiple recipients whether stored as a list or a string
    recipients = smtp_config["recipient"]
    if isinstance(recipients, list):
        recipient_str = ", ".join(recipients)
    else:
        recipient_str = recipients  # Assumes comma-separated string

    sender = SMTP_SENDER or smtp_user

    msg = EmailMessage()
    msg.set_content(report_body)
    msg["Subject"] = f"GCP Month-to-Date Billing Report - {datetime.now(ZoneInfo(TIMEZONE)).date()}"
    msg["From"] = sender
    msg["To"] = recipient_str  # EmailMessage accepts comma-separated email addresses

    with smtplib.SMTP(smtp_host, SMTP_PORT) as server:
        server.starttls()
        server.login(smtp_user, smtp_password)
        # Pass the list or comma-separated string to send_message
        server.send_message(msg)
    
    logger.info("Billing report successfully sent via email to: %s", recipient_str)


@functions_framework.http
def billing_report(request):
    if request.method != "POST":
        return ("Use POST to run the report.", 405)

    try:
        rows = fetch_billing_data()
        report_text = generate_report(rows)
        send_email_report(report_text)
        return (
            {
                "status": "success",
                "service_rows": len(rows),
                "message": "Billing report generated, logged, and emailed successfully via Secret Manager JSON.",
            },
            200,
        )
    except Exception:
        logger.exception("Failed to generate or send billing report")
        return ("Billing report failed. Check Cloud Logging.", 500)