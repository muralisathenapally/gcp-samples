output "function_name" {
  description = "Deployed billing report function name."
  value       = google_cloudfunctions2_function.billing_report.name
}

output "function_uri" {
  description = "Authenticated function endpoint."
  value       = google_cloudfunctions2_function.billing_report.service_config[0].uri
}

output "runtime_service_account" {
  description = "Function runtime identity."
  value       = google_service_account.runtime.email
}

output "scheduler_service_account" {
  description = "Cloud Scheduler invocation identity."
  value       = google_service_account.scheduler.email
}

output "source_bucket" {
  description = "Bucket containing the deployment package."
  value       = google_storage_bucket.source.name
}
