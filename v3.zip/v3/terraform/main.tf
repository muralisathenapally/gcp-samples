locals {
  function_name  = "gcp-billing-report"
  scheduler_name = "gcp-billing-report-daily"

  billing_table = format(
    "%s.%s.%s",
    var.billing_project_id,
    var.billing_dataset_id,
    var.billing_table_id
  )
}

resource "google_project_service" "apis" {
  for_each = toset([
    "cloudfunctions.googleapis.com",
    "run.googleapis.com",
    "cloudbuild.googleapis.com",
    "artifactregistry.googleapis.com",
    "cloudscheduler.googleapis.com",
    "bigquery.googleapis.com",
    "storage.googleapis.com",
    "logging.googleapis.com",
    "secretmanager.googleapis.com",
  ])

  project            = var.project_id
  service            = each.value
  disable_on_destroy = false
}

resource "random_id" "bucket_suffix" {
  byte_length = 4
}

resource "google_storage_bucket" "source" {
  project                     = var.project_id
  name                        = "${var.project_id}-billing-report-${random_id.bucket_suffix.hex}"
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  depends_on = [google_project_service.apis]
}

data "archive_file" "source" {
  type        = "zip"
  source_dir  = "${path.module}/../app"
  output_path = "${path.module}/billing-report.zip"
}

resource "google_storage_bucket_object" "source" {
  name   = "billing-report-${data.archive_file.source.output_md5}.zip"
  bucket = google_storage_bucket.source.name
  source = data.archive_file.source.output_path
}

resource "google_service_account" "runtime" {
  project      = var.project_id
  account_id   = "billing-report-runtime"
  display_name = "GCP Billing Report Runtime"

  depends_on = [google_project_service.apis]
}

resource "google_project_iam_member" "bigquery_job_user" {
  project = var.billing_project_id
  role    = "roles/bigquery.jobUser"
  member  = "serviceAccount:${google_service_account.runtime.email}"
}

resource "google_bigquery_dataset_iam_member" "billing_reader" {
  project    = var.billing_project_id
  dataset_id = var.billing_dataset_id
  role       = "roles/bigquery.dataViewer"
  member     = "serviceAccount:${google_service_account.runtime.email}"
}

resource "google_secret_manager_secret_iam_member" "secret_accessor" {
  secret_id = var.smtp_secret_id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.runtime.email}"
}

resource "google_cloudfunctions2_function" "billing_report" {
  project  = var.project_id
  name     = local.function_name
  location = var.region

  build_config {
    runtime     = "python313"
    entry_point = "billing_report"

    source {
      storage_source {
        bucket = google_storage_bucket.source.name
        object = google_storage_bucket_object.source.name
      }
    }
  }

  service_config {
    service_account_email = google_service_account.runtime.email
    available_memory      = "256M"
    timeout_seconds       = 120
    max_instance_count    = 2
    min_instance_count    = 0
    ingress_settings      = "ALLOW_ALL"

    environment_variables = {
      BILLING_TABLE  = local.billing_table
      TIMEZONE       = var.timezone
      SMTP_SECRET_ID = var.smtp_secret_id
      PROJECT_ID     = var.project_id
    }
  }

  depends_on = [
    google_project_service.apis,
    google_project_iam_member.bigquery_job_user,
    google_bigquery_dataset_iam_member.billing_reader,
    google_secret_manager_secret_iam_member.secret_accessor,
  ]
}

resource "google_service_account" "scheduler" {
  project      = var.project_id
  account_id   = "billing-report-scheduler"
  display_name = "GCP Billing Report Scheduler"

  depends_on = [google_project_service.apis]
}

resource "google_cloud_run_v2_service_iam_member" "scheduler_invoker" {
  project  = var.project_id
  location = var.region
  name     = google_cloudfunctions2_function.billing_report.name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.scheduler.email}"

  depends_on = [google_cloudfunctions2_function.billing_report]
}

# Allow the Cloud Scheduler service account to act as itself to generate OIDC tokens
resource "google_service_account_iam_member" "scheduler_token_creator" {
  service_account_id = google_service_account.scheduler.name
  role               = "roles/iam.serviceAccountTokenCreator"
  member             = "serviceAccount:${google_service_account.scheduler.email}"
}

resource "google_cloud_scheduler_job" "billing_report" {
  project     = var.project_id
  region      = var.region
  name        = local.scheduler_name
  description = "Run the GCP monthly-to-date billing report"
  schedule    = var.schedule
  time_zone   = var.timezone

  http_target {
    http_method = "POST"
    uri         = google_cloudfunctions2_function.billing_report.service_config[0].uri

    oidc_token {
      service_account_email = google_service_account.scheduler.email
      audience              = google_cloudfunctions2_function.billing_report.service_config[0].uri
    }
  }

  depends_on = [
    google_project_service.apis,
    google_cloud_run_v2_service_iam_member.scheduler_invoker,
    google_service_account_iam_member.scheduler_token_creator,
  ]
}