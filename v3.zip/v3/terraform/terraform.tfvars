project_id         = "psyched-circuit-405312"
billing_project_id = "psyched-circuit-405312"
billing_dataset_id = "test"
billing_table_id   = "gcp_billing_export_resource_v1_01B7A9_D05367_9489AF"

region   = "asia-south1"
timezone = "Asia/Kolkata"
schedule = "0 9 * * *"

smtp_secret_id     = "smtp-credentials"