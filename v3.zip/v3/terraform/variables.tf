variable "project_id" {
  description = "Project where the function and Scheduler will be deployed."
  type        = string
}

variable "region" {
  description = "Deployment region."
  type        = string
  default     = "asia-south1"
}

variable "billing_project_id" {
  description = "Project containing the BigQuery billing export."
  type        = string
}

variable "billing_dataset_id" {
  description = "BigQuery billing export dataset ID."
  type        = string
}

variable "billing_table_id" {
  description = "BigQuery billing export table ID."
  type        = string
}

variable "timezone" {
  description = "Timezone used for reporting and scheduling."
  type        = string
  default     = "Asia/Kolkata"
}

variable "schedule" {
  description = "Cron schedule for the report."
  type        = string
  default     = "0 9 * * *"
}

variable "smtp_secret_id" {
  description = "The name of the Secret Manager secret containing SMTP JSON credentials."
  type        = string
  default     = "smtp-credentials"
}