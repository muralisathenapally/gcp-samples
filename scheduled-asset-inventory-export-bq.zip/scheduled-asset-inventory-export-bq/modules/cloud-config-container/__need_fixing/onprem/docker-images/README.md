# Supporting container images

The images in this folder are used by the [`onprem` module](../).